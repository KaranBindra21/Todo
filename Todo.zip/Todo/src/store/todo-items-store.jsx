import { createContext,useReducer } from "react";

export const TodoItemsContext = createContext({
  todoItems: [],
  addNewItem: () => {},
  deleteItem: () => {},
});

const todoReducer = (curretTodo, action) => {
  let newTodoItems = curretTodo;
  if (action.type == "ADD_ITEM") {
    console.log(action.payload.itemName, action.payload.itemDate);
    newTodoItems = [
      ...curretTodo,
      { name: action.payload.itemName, dueDate: action.payload.itemDate },
    ];
  } else if (action.type === "DELETE_ITEM") {
    newTodoItems = curretTodo.filter(
      (item) => item.name !== action.payload.itemName
    );
  }
  return newTodoItems;
};

const TodoItemContextProvider = ({ children }) => {
  const [todoItems, dispatcherTodo] = useReducer(todoReducer, []);

  const addNewItem = (itemName, itemDate) => {
    const itemAction = {
      type: "ADD_ITEM",
      payload: {
        itemName,
        itemDate,
      },
    };
    dispatcherTodo(itemAction);
  };

  const deleteItem = (itemName) => {
    const itemAction = {
      type: "DELETE_ITEM",
      payload: {
        itemName,
      },
    };
    dispatcherTodo(itemAction);
  };

  return (
    <TodoItemsContext.Provider value={{ todoItems, addNewItem, deleteItem }}>
      {children}
    </TodoItemsContext.Provider>
  );
};

export default TodoItemContextProvider;
