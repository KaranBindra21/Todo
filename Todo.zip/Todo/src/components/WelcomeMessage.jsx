import { useContext } from "react";
import { TodoItemsContext } from "../store/todo-items-store";

const WelcomeMessage = () => {
  const todoObj = useContext(TodoItemsContext);
  const todoItems = todoObj.todoItems;

  return todoItems.length === 0 && <p>Enjoy Your Day</p>;
};

export default WelcomeMessage;
