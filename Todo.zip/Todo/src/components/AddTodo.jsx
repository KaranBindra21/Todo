import { useContext, useRef } from "react";
import { TodoItemsContext } from "../store/todo-items-store";

function AddTodo({}) {  
  const {addNewItem}=useContext(TodoItemsContext)
  const todoNameElement = useRef();
  const todoDateElement = useRef();

  const handleAddbutton = (event) => {
    event.preventDefault();
    const todoName = todoNameElement.current.value;
    const todoDate = todoDateElement.current.value;
    todoNameElement.current.value="";
    todoDateElement.current.value="";
    addNewItem(todoName, todoDate);
  };

  return (
    <form className="row kg-row" onSubmit={handleAddbutton}>
      <div className="col-4">
        <input
          type="text"
          placeholder="Enter Todo Here"
          ref={todoNameElement}
        />
      </div>
      <div className="col-4">
        <input type="date" ref={todoDateElement} />
      </div>
      <div className="col-4">
        <button
          type="submit"
          className="btn btn-success"
        >
          Add
        </button>
      </div>
    </form>
  );
}

export default AddTodo;
